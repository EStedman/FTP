
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;

public class ServerHandler extends Thread {
	
	private static int id = 0;
	
	private ArrayList<Users> userList;
	private Socket socket;
	
	private int getUniqueId(){
		synchronized(this){
			return ++id;
		}
	}
	
	public void newUserList(){
		userList = new ArrayList<Users>();
	}
	
	public void addPeer(Users user){
		userList.add(user);
	}
	
	public Boolean addAllUser(ArrayList<Users> user){
		userList.addAll(user);
		return true;
	}
	
	public ServerHandler(Socket socket){
		this.socket = socket;
	}
	
	public Boolean search(String fileName){
		newUserList();
		return (CentralIndexingServer.getIndex().containsKey(fileName))
				? addAllUser(CentralIndexingServer.getIndex().get(fileName))
				: false;
	}
	
	public void run(){
		
		try{
			DataInputStream dataIn = new DataInputStream(socket.getInputStream());
			DataOutputStream dataOut = new DataOutputStream(socket.getOutputStream());
			
			byte option = dataIn.readByte();
			
			switch(option){
				case 0:
					int userID = getUniqueId();
					
					Boolean end = false;
					ArrayList<String> fileNames = new ArrayList<String>();
					int numFiles = 0, port = 0;
					String address = null;
					
					while(!end){
						byte messageType = dataIn.readByte();
						
						 switch(messageType){
						 	case 1:
						 		numFiles = dataIn.readInt();
						 		System.out.println("\nPeer " + userID + " registering with " + numFiles + " files:");
						 		break;
						 	case 2:
						 		for(int i = 0; i < numFiles; i++){
						 			fileNames.add(dataIn.readUTF());
						 			System.out.println(fileNames.get(i));
						 		}
						 		break;
						 	case 3:
						 		address = dataIn.readUTF();
						 		break;
						 	case 4:
						 		port = dataIn.readInt();
						 		break;
						 	default:
						 		end = true;
						 }
					}
					
					synchronized(this){
						CentralIndexingServer.registry(userID, numFiles, fileNames, address, port);
					}
					
					dataOut.writeInt(userID);
					dataOut.flush();
					socket.close();
					break;
				case 1:
					String fileName = dataIn.readUTF();
					//System.out.println(dataIn.readUTF());
					Boolean b = search(fileName);
					try {
						Thread.sleep(1);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					if(b){
						dataOut.writeByte(1);
						dataOut.writeInt(userList.size());
						dataOut.flush();
						//System.out.println(peerList.size());
						for(Users p : userList){
							//System.out.println(p.getAddress() + p.getPort());
							dataOut.writeUTF(p.getAddress() + ":" + p.getPort() + ":" + p.getUserID());
							dataOut.flush();
						}
					}else {
						dataOut.writeByte(0);
						dataOut.flush();
					}
					socket.close();
					break;
				default:
					System.out.println("Not an option");
				
			}
		}catch (IOException ioe){
			ioe.printStackTrace();
		}
		
	}
}