import java.io.*;
import java.net.*;

public class P2PServer {
	public P2PServer(int port) throws IOException{
		ServerSocket server = new ServerSocket(port);
		while(true){
			Socket client = server.accept();
			DataInputStream in = new DataInputStream(client.getInputStream());
			String name = in.readUTF();
			
			System.out.println("New client "+name+" from "+client.getInetAddress());
			ServerHandler user = new ServerHandler(client);
			user.start();
		}
		
	}
	
	public static void main (String args[]) throws IOException{
		if(args.length != 1){
			throw new RuntimeException("Syntaz: java P2PServer <port>");
		}
		new P2PServer (Integer.parseInt(args[0]));
	}
}
