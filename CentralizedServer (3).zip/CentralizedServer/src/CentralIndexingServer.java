import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CentralIndexingServer {
	
	private static Hashtable<String,ArrayList<Users>> index;
	private static int port = 3434;
	private static int numThreads = 4;
	private static UserQueue<Socket> userQueue;
	
	public static Hashtable<String,ArrayList<Users>> getIndex(){
		return index;
	}
	
	private static void server() throws IOException{
		
		@SuppressWarnings("resource")
		ServerSocket serverSocket = new ServerSocket(port);
		
		while(true){
			System.out.println("\nWaiting for new user...");
			Socket socket = serverSocket.accept();
			synchronized(userQueue){
				userQueue.add(socket);
			}
		}
	}

	private static void income() throws IOException{
		ExecutorService executor = Executors.newFixedThreadPool(numThreads);

		while(true){
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if(userQueue.peek() == null)
				continue;
			synchronized(userQueue){
				//System.out.println("Added to executor");
				Socket socket = userQueue.poll();
				ServerHandler s = new ServerHandler(socket);
				executor.execute(s);
			}
		}
		
	}
	
	public static void registry(int userID, int numFiles, ArrayList<String> fileNames, String address, int port){
		for(String fileName : fileNames){
			if(index.containsKey(fileName)){
				index.get(fileName).add(new Users(userID, numFiles, fileNames, address, port));
			}else {
				index.put(fileName, new ArrayList<Users>());
				index.get(fileName).add(new Users(userID, numFiles, fileNames, address, port));
			}
			
		}
	}
	
	public static void main(String[] args) throws IOException {
		index = new Hashtable<String, ArrayList<Users>>();
		userQueue = new UserQueue<Socket>();
		
		if(args.length > 0){
			try{
	    		port = Integer.parseInt(args[1]);
	    	} catch (Exception e){
	    		System.out.println("Put a valid port number");
	    	}
		}
		
		new Thread() {
            public void run() {
                try {
                   server(); 
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
        
        new Thread() {
            public void run() {
                try {
                   income(); 
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
	}
}