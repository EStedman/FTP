import java.util.LinkedList;

public class UserQueue<T> {
	
	private LinkedList<T> queue;
	
	public T peek(){
		return queue.peek();
	}
	
	public T poll(){
		return queue.poll();
	}
	
	public void add(T t){
		queue.add(t);
		
	}
	
	public UserQueue(){
		queue = new LinkedList<T>();
	}

}